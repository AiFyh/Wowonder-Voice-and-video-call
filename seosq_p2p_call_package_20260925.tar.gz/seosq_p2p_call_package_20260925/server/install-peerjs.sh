#!/bin/bash
# ============================================================================
# 自建 PeerJS 信令服务 —— 安装脚本（在【目标服务器】上执行，需要 root）
#
#   1. 检查 Node 运行时（本包要求 Node 16；CentOS 7/glibc 2.17 装不了 Node ≥18）
#   2. 落地 /www/server/peerjs（server.js + package.json + 依赖）
#   3. 安装 systemd 单元并启动（覆盖同名文件前会自动备份）
#   4. 自检：curl 127.0.0.1:9000/peerjs/id 应返回一段 JSON（peerjs 的随机 id）
#
# 用法：
#   bash install-peerjs.sh
#   NODE_BIN=/usr/bin/node TARGET=/www/server/peerjs bash install-peerjs.sh
#
# ⚠ 本脚本只创建/更新「peerjs 信令服务」自己，不动 Apache、coturn、站点代码；
#   Apache 反代、TURN 中继、站点侧文件请按 README.md 的对应小节操作。
# ============================================================================
set -euo pipefail

NODE_BIN="${NODE_BIN:-/www/server/nodejs/v16.20.2/bin/node}"
TARGET="${TARGET:-/www/server/peerjs}"
SRC="$(cd "$(dirname "$0")" && pwd)/peerjs"
STAMP="$(date +%Y%m%d_%H%M%S)"
NPM_BIN="$(dirname "$NODE_BIN")/npm"

echo "== [1/5] 检查 Node 运行时 =="
if [ ! -x "$NODE_BIN" ]; then
    echo "✗ 找不到可执行的 Node: $NODE_BIN"
    echo "  请先用面板「Node 版本管理器」安装 Node 16，或指定 NODE_BIN=/path/to/node"
    exit 1
fi
echo "✓ $NODE_BIN -> $("$NODE_BIN" -v)"

echo "== [2/5] 落地服务文件到 $TARGET =="
mkdir -p "$TARGET"
cp -f "$SRC/server.js" "$SRC/package.json" "$SRC/package-lock.json" "$TARGET/"
if [ -d "$SRC/node_modules" ]; then
    echo "  使用随包附带的 node_modules（离线可用）"
    cp -a "$SRC/node_modules" "$TARGET/"
else
    echo "  随包无 node_modules，改用 npm 安装依赖…"
    ( cd "$TARGET" && "$NPM_BIN" install --omit=dev )
fi
echo "✓ 依赖就绪：$("$NODE_BIN" -e "require('$TARGET/node_modules/peer/package.json');console.log('peer '+require('$TARGET/node_modules/peer/package.json').version)" 2>/dev/null || echo '（未能校验 peer 版本）')"

echo "== [3/5] 安装 systemd 单元 =="
UNIT=/etc/systemd/system/peerjs.service
if [ -f "$UNIT" ]; then
    cp -a "$UNIT" "${UNIT}.bak_${STAMP}"
    echo "  已备份原单元 -> ${UNIT}.bak_${STAMP}"
fi
sed -e "s|^WorkingDirectory=.*|WorkingDirectory=${TARGET}|" \
    -e "s|^ExecStart=.*|ExecStart=${NODE_BIN} ${TARGET}/server.js|" \
    "$(cd "$(dirname "$0")" && pwd)/systemd/peerjs.service" > "$UNIT"
chmod 644 "$UNIT"
echo "✓ $UNIT"

echo "== [4/5] 启动服务 =="
systemctl daemon-reload
systemctl enable peerjs >/dev/null
systemctl restart peerjs
sleep 2
systemctl is-active peerjs

echo "== [5/5] 自检 =="
if curl -s --max-time 5 http://127.0.0.1:9000/peerjs/id | grep -q '"id"'; then
    echo "✓ 信令服务应答正常：$(curl -s --max-time 5 http://127.0.0.1:9000/peerjs/id)"
else
    echo "✗ 信令服务无应答，查看日志：journalctl -u peerjs -n 50 --no-pager"
    exit 1
fi

cat <<'NEXT'

------------------------------------------------------------
信令服务已就绪，接下来（详见 README.md）：
  1) Apache 反代：把 server/apache/peerjs-ws.conf 放到面板 vhost 的 extension 目录，
     并做一次 graceful 重载（本机为）
       /www/server/apache/bin/apachectl -k graceful
     ⚠ 若目标机的 panel vhost 目录不是 /www/server/panel/vhost/apache，
       请把反代片段直接放进该站点的 vhost 配置里。
  2) 放行端口：TCP 443（已有）、UDP 3478、UDP 50000-50100。
  3) coturn：见 server/coturn/README-coturn.md。
  4) 站点侧：按 README.md 第 3 节放文件、合片段、跑 sql/wo_config-required.sql。
------------------------------------------------------------
NEXT
