/**
 * SEO社区(seosq.com) 自建 PeerJS 信令服务
 *
 * 目的：替代公共云 0.peerjs.com —— 公共云只做信令、且在大陆网络下经常很慢甚至连不上，
 *      音视频通话会一直卡在"请稍候"。本服务只转发 SDP/ICE 信令（不中转媒体），
 *      媒体仍走浏览器之间的 P2P / 自建 TURN 中继。
 *
 * 部署形态：
 *   - 只监听 127.0.0.1:9000（不直接对公网开放，也不需要额外证书）
 *   - Apache 反向代理：wss://<站点域名>/peerjs  ->  ws://127.0.0.1:9000/peerjs
 *   - 前端（themes/Sean）里 new Peer(...) 的 host 改为 location.hostname、path 保持 '/'
 *
 * 日志：服务端每次客户端连上/断开都会打印，便于判断"浏览器到底有没有连到信令"。
 *      日志写在 stdout，由 systemd 收集（journalctl -u peerjs -f）。
 */
const { PeerServer } = require('peer');

const PORT = parseInt(process.env.PEERJS_PORT || '9000', 10);
const HOST = process.env.PEERJS_HOST || '127.0.0.1';
const PATH = process.env.PEERJS_PATH || '/';   // 与前端 path 一致；客户端实际请求 /peerjs
const KEY = process.env.PEERJS_KEY || 'peerjs';

function ts() {
  return new Date().toISOString().replace('T', ' ').slice(0, 19);
}

const peerServer = PeerServer({
  port: PORT,
  host: HOST,
  path: PATH,
  key: KEY,
  proxied: true,           // 位于 Apache 反向代理之后，信任 X-Forwarded-For
  allow_discovery: false,  // 禁止列举在线 id，避免被扫
  alive_timeout: 60000,    // 客户端心跳超时(ms)
});

peerServer.on('connection', function (client) {
  console.log('[' + ts() + '] connected   id=' + client.getId());
});
peerServer.on('disconnect', function (client) {
  console.log('[' + ts() + '] disconnected id=' + client.getId());
});
peerServer.on('error', function (err) {
  console.log('[' + ts() + '] error: ' + (err && err.message ? err.message : err));
});

console.log('[' + ts() + '] peerjs signaling listening on ' + HOST + ':' + PORT + ' path=' + PATH + ' key=' + KEY);
