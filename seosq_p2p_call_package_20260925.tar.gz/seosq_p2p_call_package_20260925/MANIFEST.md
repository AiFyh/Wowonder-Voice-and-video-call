# MANIFEST —— 文件清单与用途

包名：`seosq_p2p_call_package_20260925`　导出自 www.seosq.com（WowWonder，主题 Sean）　导出日期：2026-09-25
校验值：见同目录 `MANIFEST.md5`（覆盖除 `server/peerjs/node_modules/` 外的全部文件）

## 站点侧（按站点根目录相对路径放置）

| 文件 | 用途 | 备注 |
|---|---|---|
| `website/xhr/create_new_video_call.php` | 发起视频呼叫：生成 `seosq-`+10 位房间号，写 `Wo_VideoCalles`，返回通话页 URL 与呼叫弹窗 HTML | 走 `p2p_chat_video` 分支时不需要第三方 token |
| `website/xhr/create_new_audio_call.php` | 发起语音呼叫：同上，写 `Wo_AudioCalles` | |
| `website/xhr/answer_call.php` | 接听：置 `active=1`，渲染 `modals/talking`（语音弹窗，内含 P2P 逻辑） | |
| `website/xhr/check_for_answer.php` | 主叫方轮询视频呼叫是否被接听 | |
| `website/xhr/check_for_audio_answer.php` | 主叫方轮询语音呼叫是否被接听；被拒时返回拒接文案 | |
| `website/xhr/decline_call.php` | 被叫拒接 | |
| `website/xhr/cancel_call.php` | 挂断/取消：删除本用户相关的通话房间记录 | |
| `website/xhr/close_call.php` | 关闭语音弹窗时置 `declined=1` | |
| `website/xhr/p2p_turn.php` | 下发 ICE 列表（STUN + TURN 临时账号）；含 `wo_turn_secret()` / `wo_turn_public_ip()` | **不含任何密钥明文**，密钥从服务器文件读 |
| `website/xhr/call_log.php` | 通话结束写入聊天记录（`type_two='call_log'`），按房间号去重 | 二开新增（2026-09-25） |
| `website/xhr/update_data.php` | 后台轮询：检测到来电时前端弹「来电」窗；通话结束后清理弹窗 | 通话分支见 `snippets/` |
| `website/sources/video.php` | 通话页控制器 `/video-call/<id>`（区分主叫/被叫角色） | 需要 `index.php` 路由 + `.htaccess` 伪静态 |
| `website/sources/video_call_api.php` | 旧版 `video-call-api` 路由（手机端） | 未改动 |
| `website/themes/Sean/layout/video/content.phtml` | 通话页容器 + 通话时长元素 + 挂断按钮 | |
| `website/themes/Sean/layout/video/p2p.phtml` | **本方案核心**：PeerJS 建连、ICE、数据通道 bye 通知、计时、挂断断上报通话记录 | |
| `website/themes/Sean/layout/video/agora.phtml` / `twilio.phtml` | Agora / Twilio 通道模板（备用，本机未启用） | |
| `website/themes/Sean/layout/modals/talking.phtml` | 语音通话弹窗（P2P 分支 + 计时 + 挂断上报） | |
| `website/themes/Sean/layout/modals/calling.phtml` / `calling-audio.phtml` / `in_call.phtml` / `in_audio_call.phtml` | 视频/语音「呼叫中」「来电」弹窗 | |
| `website/themes/Sean/javascript/peerjs.min.js` | 浏览器端 PeerJS v1.5.5 | |
| `website/api/phone/*.php`（4 个） | 旧版手机 App 通话接口 | 未改动，随包仅供参考 |

## 共享文件的合入片段

| 文件 | 对应目标 | 说明 |
|---|---|---|
| `snippets/index.php.routes-snippet.txt` | `index.php` | `video-call` / `video-call-api` 两条路由（源站两处） |
| `snippets/.htaccess.call-rewrite-snippet.txt` | `.htaccess` | 两条 RewriteRule |
| `snippets/script.js.call-snippet.js` | `themes/Sean/javascript/script.js` | 片段 A(323-358) 来电轮询 / B(361-541) `Wo_intervalUpdates` / C(2440-2627) 应答·拒接·挂断·发起通话；三段各自通过 `node --check` |
| `snippets/style.css.call-snippets.css` | `themes/Sean/stylesheet/style.css` | 两块二开新增样式（通话时长胶囊、聊天记录通话记录行）+ 主题原有通话样式行号索引 |

## 服务端

| 文件 | 部署位置 | 用途 |
|---|---|---|
| `server/peerjs/server.js` | `/www/server/peerjs/server.js` | PeerJS 信令服务（仅监听 127.0.0.1:9000，proxied、allow_discovery=false） |
| `server/peerjs/package.json` / `package-lock.json` | 同上 | 依赖声明（`peer@^1.0.2`）与锁定版本 |
| `server/peerjs/node_modules/`（1134 个文件，19 MB） | 同上 | **离线可用的依赖**；也可以改用 `npm install --omit=dev` |
| `server/systemd/peerjs.service` | `/etc/systemd/system/peerjs.service` | User=www、Restart=always、Journal 输出 |
| `server/apache/peerjs-ws.conf` | 面板 vhost `extension/<域名>/` 目录 | `/peerjs/id`→http、`/peerjs`→ws 反代到 127.0.0.1:9000，`retry=0` |
| `server/coturn/turnserver.conf.template` | `/etc/coturn/turnserver.conf` | 中继/STUN 配置模板，**密钥已脱敏**（占位符） |
| `server/coturn/README-coturn.md` | —— | coturn 安装、密钥一致性、公网 IP、端口放行、日志说明 |
| `server/install-peerjs.sh` | 目标机上执行 | 一键装信令服务（会备份同名 systemd 单元，不动 Apache/coturn/站点代码） |
| `sql/wo_config-required.sql` | 目标库执行 | 5 个必填开关（幂等写法）+ 校验语句 + Memcached 缓存提醒 |

## 对照文件（勿直接覆盖其它站点）

| 文件 | 说明 |
|---|---|
| `reference-full/themes/Sean/javascript/script.js` | 源站整份脚本（381 KB），含该站其它定制，仅用于对照/还原 |
| `reference-full/themes/Sean/stylesheet/style.css` | 源站整份样式（400 KB），同上 |

## 不含的东西（有意为之）

* **任何密钥明文**：coturn `static-auth-secret` 为占位符；`/etc/turn-rest-secret` 只在文档里描述生成方法。
* 站点数据库导出、`config.php`（含库账号密码）、Cloudflare 凭据、面板配置。
* `Wo_VideoCalles` / `Wo_AudioCalles` 建表 SQL（由 WowWonder 主程序自带，文档里给了存在性检查语句）。
