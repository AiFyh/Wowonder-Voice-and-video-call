/* ============================================================================
 * 通话相关 JS 片段 —— 来源: themes/Sean/javascript/script.js（源站 3779 行）
 * 说明: script.js 是主题共享大文件（含站内其它定制），这里只抽出与语音/视频通话有关的
 *       函数与轮询分支（三段各自都能通过 node --check）；需要整份原文时见
 *       reference-full/themes/Sean/javascript/script.js。
 * ============================================================================ */

/* ---------- 片段 A（源行 323-358）：来电应答轮询 Wo_CheckForCallAnswerTabs / Wo_CheckForAudioCallAnswerTabs ---------- */
function Wo_CheckForCallAnswerTabs(id) {
  $.get(Wo_Ajax_Requests_File(), {f:'check_for_answer', id:id}, function (data1) {
    if (data1.status == 400 || data1.status == 200) {
      clearTimeout(checkcalls);
      setTimeout(function () {
        $( '#re-calling-modal' ).remove();
        $( '.modal-backdrop' ).remove();
        $( 'body' ).removeClass( "modal-open" );
        document.title = document_title;
      }, 3000);
    }
  });
  checkcalls = setTimeout(function () {
      Wo_CheckForCallAnswerTabs(id);
  }, 2000);
}
function Wo_CheckForAudioCallAnswerTabs(id) {
  $.get(Wo_Ajax_Requests_File(), {f:'check_for_audio_answer', id:id}, function (data1) {
    if (data1.status == 400 || data1.status == 200) {
      clearTimeout(checkcalls);
      setTimeout(function () {
        $( '#re-calling-modal' ).remove();
        $( '.modal-backdrop' ).remove();
        $( 'body' ).removeClass( "modal-open" );
        document.title = document_title;
      }, 3000);
      if (data1.status == 400) {
        Wo_PlayVideoCall('stop');
        Wo_PlayAudioCall('stop');
      }
    }
  });
  checkcalls = setTimeout(function () {
      Wo_CheckForAudioCallAnswerTabs(id);
  }, 2000);
}

/* ---------- 片段 B（源行 361-541）：后台轮询函数 Wo_intervalUpdates 整体 —— 来电弹窗、通话结束/被拒后清理弹窗都在这里 ---------- */
function Wo_intervalUpdates(force_update = 0, loop = 0) {
	if (node_socket_flow == "0" || force_update == 1) {
	var check_posts = true;
	var hash_posts = true;
	if ($('.posts-hashtag-count').length == 0) {
      hash_posts = false;
	}
	var api = $('#api').val();
	if (api) {
      return false;
	}
	if ($('.posts-count').length == 0 || hash_posts == true) {
      check_posts = false;
	}
	if(typeof ($('#posts').attr('data-story-user')) == "string") {
      user_id = $('#posts').attr('data-story-user');
	} else {
      user_id = 0;
	}
	before_post_id = 0;
	if($('.post-container').length > 0) {
      var before_post_id = $('.post-container  > .post:not(.boosted)').attr('data-post-id');
	}
	var notification_container = $('.notification-container');
	var messages_notification_container = $('.messages-notification-container');
	var follow_requests_container = $('.requests-container');
	var ajax_request = {
      f: 'update_data',
      user_id: user_id,
      before_post_id: before_post_id,
      check_posts:check_posts,
      hash_posts:hash_posts,
      hash_id: $('.main_session').val()
    };
	if (hash_posts == true) {
      ajax_request['hashtagName'] = $('#hashtagName').val();
	}
	$.get(Wo_Ajax_Requests_File(), ajax_request, function (data) {
	  if (node_socket_flow == "0" || force_update == 0 || loop == 1) {
          clearTimeout(intervalUpdates);
          intervalUpdates = setTimeout(function () {
            Wo_intervalUpdates(force_update);
          } , 5000);
      }
    if (hash_posts == true) {
        if (data.count_num > 0) {
          $('.posts-count').html(data.count);
        }
    } else {
        if (data.count_num > 0 && $('.filter-by-more').attr('data-filter-by') == 'all') {
          $('.posts-count').html(data.count);
        }
    }
    if(typeof (data.notifications) != "undefined" && data.notifications > 0) {
      notification_container.find('.new-update-alert').removeClass('hidden');
      notification_container.find('.sixteen-font-size').addClass('unread-update');
      notification_container.find('.new-update-alert').text(data.notifications).show();
      if(current_width > 800 && data.pop == 200) {
        Wo_NotifyMe(data.icon, decodeHtml(data.title), decodeHtml(data.notification_text), data.url);
      }
      if(data.notifications != current_notification_number) {
        if (data.notifications_sound == 0) {
           document.getElementById('notification-sound').play();
        }
        current_notification_number = data.notifications;
      }
    } else {
      notification_container.find('.new-update-alert').hide();
      notification_container.find('.sixteen-font-size').removeClass('unread-update');
      current_notification_number = 0;
    }
    if(typeof (data.messages) != "undefined" && data.messages > 0) {
      messages_notification_container.find('.new-update-alert').removeClass('hidden');
      messages_notification_container.find('.sixteen-font-size').addClass('unread-update');
      messages_notification_container.find('.new-update-alert').text(data.messages).show();
      if(data.messages != $("[data_messsages_count]").attr('data_messsages_count')) {
        if (data.notifications_sound == 0 && $("[data_messsages_count]").attr('data_messsages_count') < data.messages) {
          document.getElementById('message-sound').play();
        }
		$("[data_messsages_count]").attr('data_messsages_count', data.messages);
        current_messages_number = data.messages;
      }
    } else {
      messages_notification_container.find('.new-update-alert').hide();
      messages_notification_container.find('.sixteen-font-size').removeClass('unread-update');
      current_messages_number = 0;
    }
    if(typeof (data.followRequests) != "undefined" && data.followRequests > 0) {
      follow_requests_container.find('.new-update-alert').removeClass('hidden');
      follow_requests_container.find('.sixteen-font-size').addClass('unread-update');
      follow_requests_container.find('.new-update-alert').text(data.followRequests).show();
      if(data.followRequests != current_follow_requests_number) {
        current_follow_requests_number = data.followRequests;
      }
    } else {
      follow_requests_container.find('.new-update-alert').hide();
      follow_requests_container.find('.sixteen-font-size').removeClass('unread-update');
      current_follow_requests_number = 0;
    }

    if(typeof (data.messages) != "undefined" && data.messages > 0 || typeof (data.notifications) != "undefined" && data.notifications > 0 || typeof (data.followRequests) != "undefined" && data.followRequests > 0) {
      title = Number(data.notifications) + Number(data.messages) + Number(data.followRequests);
      document.title = '(' + title + ') ' + document_title;
    } else {
      document.title = document_title;
    }
    if (data.calls == 200 && $('#re-calling-modal').length == 0 && $('#re-talking-modal').length == 0) {
		if (node_socket_flow != "1") {
          Wo_CheckForCallAnswerTabs(data.call_id);
        }
         if ($('#calling-modal').length == 0) {
          $('body').append(data.calls_html);
          if (!$('#re-calling-modal').hasClass('calling')) {
            $('#re-calling-modal').modal({
             show: true
            });
            Wo_PlayVideoCall('play');
			$('body').addClass('tag_call_incoming');
          }
          document.title = 'New video call..';
          setTimeout(function () {
            Wo_CloseModels();
            $('#re-calling-modal').addClass('calling');
            Wo_PlayVideoCall('stop');
            document.title = document_title;
            setTimeout(function () {
              $( '#re-calling-modal' ).remove();
              $( '.modal-backdrop' ).remove();
              $( 'body' ).removeClass( "modal-open" );
			  $('body').removeClass('tag_call_incoming');
            }, 3000);
            $( '#re-calling-modal' ).remove();
            $('.modal-backdrop.in').hide();
          }, 40000);
         } 
    } else if (data.audio_calls == 200 && $('#re-calling-modal').length == 0 && $('#re-talking-modal').length == 0) {
		if (node_socket_flow != "1") {
          Wo_CheckForAudioCallAnswerTabs(data.call_id);
        }
      if ($('#calling-modal').length == 0) {
          $('body').append(data.audio_calls_html);
          if (!$('#re-calling-modal').hasClass('calling')) {
            $('#re-calling-modal').modal({
             show: true
            });
            Wo_PlayVideoCall('play');
			$('body').addClass('tag_call_incoming');
          }
          document.title = 'New audio call..';
          setTimeout(function () {
            if ($('#re-talking-modal').length == 0) {
               Wo_CloseModels();
               $('#re-calling-modal').addClass('calling');
               Wo_PlayVideoCall('stop');
               document.title = document_title;
               setTimeout(function () {
                 $( '#re-calling-modal' ).remove();
                 $( '.modal-backdrop' ).remove();
                 $( 'body' ).removeClass( "modal-open" );
				 $('body').removeClass('tag_call_incoming');
               }, 3000)
            }
          }, 40000);
         } 
    } else if (data.is_audio_call == 0 && data.is_call == 0 && ($('#re-calling-modal').length > 0 || $('#re-talking-modal').length > 0)) {
        Wo_PlayVideoCall('stop');
        $( '#re-calling-modal' ).remove();
        $( '.modal-backdrop' ).remove();
        $( 'body' ).removeClass( "modal-open" );
		$('body').removeClass('tag_call_incoming');
    }
  }).fail(function() {
      clearTimeout(intervalUpdates);
		  if (force_update == 0) {
            intervalUpdates = setTimeout(function () {
              Wo_intervalUpdates(force_update);
            } , 5000);
          }
    });
	}
}

/* ---------- 片段 C（源行 2440-2627）：应答/拒接/挂断/发起通话（含 Wo_GenerateVideoCall、Wo_GenerateVoiceCall）+ 铃声 ---------- */
function Wo_CheckForCallAnswer(id) {
  $.get(Wo_Ajax_Requests_File(), {f:'check_for_answer', id:id}, function (data1) {
    if (data1.status == 200) {
      clearTimeout(checkcalls);
	  $('#calling-modal').find('p').html(data1.text_answered + ". " + data1.text_please_wait);
      setTimeout(function () {
          window.location.href = data1.url;
      }, 1000);
      return false;
    } else if (data1.status == 400) {
      clearTimeout(checkcalls);
      Wo_PlayAudioCall('stop');
	  $('#calling-modal').find('p').html(data1.text_call_declined + ". " + data1.text_call_declined_desc);
    }
    checkcalls = setTimeout(function () {
        Wo_CheckForCallAnswer(id);
    }, 2000);
  });
}

function Wo_CheckForAudioCallAnswer(id) {
  $.get(Wo_Ajax_Requests_File(), {f:'check_for_audio_answer', id:id}, function (data1) {
    if (data1.status == 200) {
      clearTimeout(checkcalls);
	  $('#calling-modal').find('p').html(data1.text_answered + ". " + data1.text_please_wait);
      Wo_PlayAudioCall('stop');
      setTimeout(function () {
          $( '#calling-modal' ).remove();
          $( '.modal-backdrop' ).remove();
          $( 'body' ).removeClass( "modal-open" );
          $('body').append(data1.calls_html);
          $('#re-talking-modal').modal({
            show: true
          });
      }, 3000);
    } else if (data1.status == 400) {
      clearTimeout(checkcalls);
      Wo_PlayAudioCall('stop');
	  $('#calling-modal').find('p').html(data1.text_call_declined + ". " + data1.text_call_declined_desc);
    } else {
      checkcalls = setTimeout(function () {
        Wo_CheckForAudioCallAnswer(id);
      }, 2000);
    }
  });
}

function Wo_AnswerCall(id, url, type) {
  type1 = 'video';
  if (type == 'video') {
     type1 = 'video';
  } else if (type == 'audio') {
    type1 = 'audio';
  }
  $('#re-calling-modal').find('.btn').attr('disabled','disabled');
  $.get(Wo_Ajax_Requests_File(), {f:'answer_call', id:id, type:type1}, function (data) {
    Wo_PlayVideoCall('stop');
    if (type1 == 'video') {
      if (data.status == 200) {
         window.location.href = url;
      }
    } else {
      $( '#re-calling-modal' ).remove();
      $( '.modal-backdrop' ).remove();
      $( 'body' ).removeClass( "modal-open" );
	  $('body').removeClass('tag_call_incoming');
      $('body').append(data.calls_html);
      $('#re-talking-modal').modal({
        show: true
      });
    }
  });
}
function Wo_DeclineCall(id, url, type) {
  type1 = 'video';
  if (type == 'video') {
     type1 = 'video';
  } else if (type == 'audio') {
    type1 = 'audio';
  }
  $('#re-calling-modal').find('.btn').attr('disabled','disabled');
  $.get(Wo_Ajax_Requests_File(), {f:'decline_call', id:id, type:type1}, function (data) {
    if (data.status == 200) {
	  if (node_socket_flow == "1") {
        socket.emit("decline_call", {user_id: _getCookie("user_id") });
      }
      Wo_PlayVideoCall('stop');
	  Wo_PlayAudioCall('stop');
      $( '#re-calling-modal' ).remove();
      $( '.modal-backdrop' ).remove();
      $( 'body' ).removeClass( "modal-open" );
	  $('body').removeClass('tag_call_incoming');
    }
  });
}

function Wo_CloseCall(id) {
  $('#re-talking-modal').find('.decline-call').attr('disabled','disabled');
  $.get(Wo_Ajax_Requests_File(), {f:'close_call', id:id}, function (data) {
    if (data.status == 200) {
      $( '#re-talking-modal' ).remove();
      $( '.modal-backdrop' ).remove();
      $( 'body' ).removeClass( "modal-open");
    }
  });
}

function Wo_CancelCall() {
  $('#calling-modal').find('.cancel-call').attr('disabled','disabled');
  $.get(Wo_Ajax_Requests_File(), {f:'cancel_call'}, function (data) {
    if (data.status == 200) {
      Wo_PlayAudioCall('stop');
      $( '#calling-modal' ).remove();
      $( '.modal-backdrop' ).remove();
      $( 'body' ).removeClass( "modal-open" );
    }
  });
}
function Wo_GenerateVideoCall(user_id1, user_id2) {
  $.get(Wo_Ajax_Requests_File(), {f:'create_new_video_call', 'new': 'true', user_id1: user_id1, user_id2:user_id2, hash_id: $('.main_session').val()}, function(data) {
      if (data.status == 200) {
		  if (node_socket_flow == "1") { 
            socket.emit("user_notification", { to_id: user_id2, user_id: _getCookie("user_id"), type: "create_video" });
          }
          $('body').append(data.html);
           $('#calling-modal').modal({
             show: true
           });
           checkcalls = setTimeout(function () {
              Wo_CheckForCallAnswer(data.id);
           }, 2000);
           setTimeout(function() {
            $('#calling-modal').find('p').html(data.text_no_answer + ". " + data.text_please_try_again_later);
			$('#calling-modal').find('.btn').addClass('call_no_answer').html('<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path fill="currentColor" d="M18.3 5.71c-.39-.39-1.02-.39-1.41 0L12 10.59 7.11 5.7c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L10.59 12 5.7 16.89c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0L12 13.41l4.89 4.89c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L13.41 12l4.89-4.89c.38-.38.38-1.02 0-1.4z"/></svg>');
            clearTimeout(checkcalls);
            Wo_PlayAudioCall('stop');
           }, 43000);
          Wo_PlayAudioCall('play');
    }
   });
}

function Wo_GenerateVoiceCall(user_id1, user_id2) {
  $.get(Wo_Ajax_Requests_File(), {f:'create_new_audio_call', 'new': 'true', user_id1: user_id1, user_id2:user_id2, hash_id: $('.main_session').val()}, function(data) {
      if (data.status == 200) {
		  if (node_socket_flow == "1") { 
            socket.emit("user_notification", { to_id: user_id2, user_id: _getCookie("user_id"), type: "create_video" });
          }
          $('body').append(data.html);
           $('#calling-modal').modal({
             show: true
           });
           checkcalls = setTimeout(function () {
              Wo_CheckForAudioCallAnswer(data.id);
           }, 2000);
           setTimeout(function() {
            $('#calling-modal').find('p').html(data.text_no_answer + ". " + data.text_please_try_again_later);
			$('#calling-modal').find('.btn').addClass('call_no_answer').html('<svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path fill="currentColor" d="M18.3 5.71c-.39-.39-1.02-.39-1.41 0L12 10.59 7.11 5.7c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L10.59 12 5.7 16.89c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0L12 13.41l4.89 4.89c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L13.41 12l4.89-4.89c.38-.38.38-1.02 0-1.4z"/></svg>');
            clearTimeout(checkcalls);
            Wo_PlayAudioCall('stop');
           }, 43000);
          Wo_PlayAudioCall('play');
    }
   });
}

function Wo_PlayAudioCall(type) {
  if (type == 'play') {
    document.getElementById('calling-sound').play();
    window.playmusic_ = setTimeout(function() {
       Wo_PlayAudioCall('play');
    }, 100);
  } else {
    clearTimeout(window.playmusic_);
    document.getElementById('calling-sound').pause();
  }
}
function Wo_PlayVideoCall(type) {
  if (type == 'play') {
    document.getElementById('video-calling-sound').play();
    window.playmusic = setTimeout(function() {
       Wo_PlayVideoCall('play');
    }, 100);
  } else {
    clearTimeout(window.playmusic);
    document.getElementById('video-calling-sound').pause();
  }
}
