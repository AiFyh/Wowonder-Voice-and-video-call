# SEO社区（WowWonder）语音/视频通话功能 —— 打包交付说明

导出自生产站点 **www.seosq.com**（2026-09-25）。本包含两部分：

1. **站点侧代码**：从「点按呼叫」到「接通/挂断」的全部 PHP / 模板 / 客户端库（`website/`）；
2. **服务端依赖与安装库**：自建 PeerJS 信令服务（含 `node_modules`）、coturn 中继配置模板、
   systemd 单元、Apache 反代配置、必填 SQL（`server/`、`sql/`）。

> 本通话功能**不用公共云信令**（原有的 `0.peerjs.com` 在大陆网络下经常连不上，表现为通话一直停在"请稍候"）。
> 现方案：自建 PeerJS 信令 + 自建 coturn（STUN/TURN）+ 浏览器间 P2P，媒体优先直连、打不通才走中继。

---

## 1. 架构与数据流

```
浏览器 A ─┐                                  ┌─ /peerjs/id  (HTTP, 取随机 id)
          ├─ wss://<站点域名>/peerjs  ──► Apache(443) ──► 127.0.0.1:9000  PeerJS 信令服务
浏览器 B ─┘        (只走 SDP/ICE 信令)            │        (systemd: peerjs, Node v16)
                                                  │
   媒体：浏览器 A ◄══ P2P 直连(UDP) ═════════════► 浏览器 B        ← 优先
             或  ◄══ TURN 中继 3478/50000-50100 ═►  coturn        ← 直连失败时
```

* **信令**：`themes/Sean/javascript/peerjs.min.js`（客户端 v1.5.5）→ `new Peer(id, {host: location.hostname, path: '/', ...})`
  → Apache 反代 → `server/peerjs/server.js`（只监听 127.0.0.1:9000，不对公网暴露，无需单独证书）。
* **ICE 服务器**：前端先带一颗兜底 STUN（源站公网 IP），页面加载时再请求 `xhr/p2p_turn.php`，
  由服务端下发「STUN + TURN（带 10 分钟临时账号，HMAC-SHA1 时间戳账号）」动态列表；换服务器后自动纠正 IP。
* **房间**：`xhr/create_new_video_call.php` 生成 `seosq-` + 10 位随机串；主叫占房、被叫拨入（失败会重试 20 次）。
* **通话记录**：挂断时双方页面都上报 `xhr/call_log.php`，服务端按房间号去重，在聊天里写一条
  `type_two='call_log'` 的消息（显示为「通话已结束 01:21」）。

---

## 2. 依赖清单（安装库）

| 组件 | 本机实际版本 | 用途 | 安装方式 |
|---|---|---|---|
| Node.js | **v16.20.2**（`/www/server/nodejs/v16.20.2/bin/node`） | 跑信令服务 | 面板「Node 版本管理器」安装。⚠ CentOS 7 / glibc 2.17 **装不了 Node ≥18** |
| npm 包 `peer` | `^1.0.2`（本机实测安装版本见 `server/peerjs/package-lock.json`） | PeerJS 服务端 | **随包附 `node_modules`（19 MB，可离线）**；或 `npm install --omit=dev` |
| coturn | **4.6.2-2.el7**（`/usr/bin/turnserver`） | STUN + TURN 中继 | `yum install -y epel-release && yum install -y coturn` |
| peerjs.min.js | v1.5.5（随主题，87 KB） | 浏览器端 WebRTC 封装 | 随包 → `themes/Sean/javascript/peerjs.min.js` |
| Apache 模块 | 2.4.68，需 `mod_proxy` + **`mod_proxy_wstunnel`** | 反代 WSS | 本机已启用；目标机用 `httpd -M \| grep -E 'proxy'` 核对 |
| PHP | 7.4.33 | 站点侧（`hash_hmac` / `base64_encode` / `stream_socket_client` UDP / `preg_match`） | 无额外扩展；`disable_functions` 需为空（本机为空） |
| MySQL | 5.7.44（`GET_LOCK` 可用） | 通话房间表、通话记录消息 | 用 WowWonder 自带库；见 `sql/` |

**端口 / 网络要求**

| 端口 | 协议 | 用途 | 备注 |
|---|---|---|---|
| 443 | TCP | 站点 + WSS 信令（`/peerjs`） | 走 Cloudflare 代理即可（信令是 TCP，实测通过） |
| 3478 | UDP | STUN / TURN | **必须直连源站 IP**，云安全组放行 |
| 50000-50100 | UDP | TURN 中继端口（`min-port`/`max-port`） | 云安全组放行 |
| 9000 | TCP | PeerJS 服务 | **只绑 127.0.0.1，不要对公网开放** |

---

## 3. 安装步骤

### 3.1 站点侧（`website/`，按站点根目录相对路径放置）

```
website/xhr/                                   # AJAX 处理器（11 个）
  create_new_video_call.php  create_new_audio_call.php   # 发起呼叫，生成房间
  answer_call.php  check_for_answer.php  check_for_audio_answer.php  decline_call.php
  cancel_call.php  close_call.php                        # 应答/拒接/挂断/取消
  p2p_turn.php                                           # 下发 STUN/TURN 列表（读 TURN 密钥）
  call_log.php                                           # 通话结束写聊天记录（二开新增）
  update_data.php                                        # 后台轮询（弹来电窗）
website/sources/video.php  video_call_api.php            # 通话页控制器 / 旧版 API
website/themes/Sean/layout/video/{content,p2p,agora,twilio}.phtml   # 通话页模板（p2p = 本方案）
website/themes/Sean/layout/modals/{talking,calling,calling-audio,in_call,in_audio_call}.phtml
website/themes/Sean/javascript/peerjs.min.js             # 客户端库
website/api/phone/{create_video_call,create_audio_call,video_call_answer,audio_call_answer}.php
                                                         # 旧版手机 App 接口（未改动，随包仅供参考）
```

**不需要改动 `requests.php`**：它按 `xhr/<f>.php` 自动加载，把文件放进去即可。

### 3.2 共享文件需要合入的片段（`snippets/`）

这四个是主题/入口的共享大文件，本包给的是从源站抽出的精确片段（都带源行号）：

| 目标文件 | 片段文件 | 要合入的内容 |
|---|---|---|
| `index.php` | `snippets/index.php.routes-snippet.txt` | `case 'video-call'` / `video-call-api` → `sources/video.php`、`sources/video_call_api.php`（源站两处：153-158、882-887） |
| `.htaccess` | `snippets/.htaccess.call-rewrite-snippet.txt` | `^video-call/([^/]+)` 与 `^video-call-api/([^/]+)` 两条 RewriteRule |
| `themes/Sean/javascript/script.js` | `snippets/script.js.call-snippet.js` | 片段 A 来电轮询、片段 B `Wo_intervalUpdates`（来电弹窗/结束清理）、片段 C 应答/拒接/挂断/发起通话。三段各自都能通过 `node --check` |
| `themes/Sean/stylesheet/style.css` | `snippets/style.css.call-snippets.css` | 通话时长胶囊 + 聊天记录通话记录行两块新样式；其余通话样式是主题自带的（片段里列了行号） |

`reference-full/` 里放了源站整份 `script.js` 与 `style.css`，只用于对照/还原（它们含该站点其它定制，别直接覆盖别的站）。

### 3.3 服务端（信令 + 中继）

```bash
# ① 信令服务（本包 server/）
bash server/install-peerjs.sh              # 自动检查 Node、落地文件、装 systemd、自检
journalctl -u peerjs -f                    # 每次客户端连接/断开都带 id

# ② Apache 反代：把反代片段放到面板 vhost 的 extension 目录（不被面板重写覆盖）
cp server/apache/peerjs-ws.conf /www/server/panel/vhost/apache/extension/<站点域名>/
/www/server/apache/bin/apachectl -k graceful     # ⚠ 本机只能这样重载（systemctl reload httpd 不适用）
curl -s https://<站点域名>/peerjs/id              # 期望：{"id":"xxxx"}（前面是反斜杠转义）

# ③ coturn 中继：见 server/coturn/README-coturn.md（含密钥一致性这个必踩坑）
```

### 3.4 数据库开关

```bash
mysql -u<用户> -p <库名> < sql/wo_config-required.sql
```

⚠ 站点启用了 **Memcached 配置缓存（TTL 300 秒）**：直接跑 SQL 后最多 5 分钟生效；
想立刻生效请清缓存或重启 memcached，推荐直接在后台「设置」里改这几项。

---

## 4. 验证清单（按顺序做，每步都有可观察结果）

1. **信令服务**：`systemctl is-active peerjs` → `active`；`curl -s http://127.0.0.1:9000/peerjs/id` → 返回 JSON id。
2. **反代**：`curl -s https://<域名>/peerjs/id` → 返回同样的 JSON。
3. **WSS 升级**：两端口打开同一站点并通话，Apache 访问日志应出现 `GET /peerjs?... 101`（WebSocket 升级）。
4. **真实通话**：A 呼叫 B → B 弹出「视频来电」→ 接听后双方有画面/声音；接通后页面显示通话时长（`00:00` 起）。
5. **TURN 中继确实被用**：通话中在服务器执行
   `ss -unap | grep -cE ':(500[0-9][0-9]|50100)'` → 有活动连接说明走了中继（直连时可能为 0，属于正常）。
6. **通话记录**：挂断后到「消息」页（或等 5 秒轮询），会话里出现居中的「通话已结束 01:21」系统行。
   ⚠ 未接通/无人接听**不会**写记录，这是有意设计。
7. **权限**：`su -s /bin/sh www -c 'test -r /etc/turn-rest-secret && echo OK'` → `OK`（www 必须能读到 TURN 密钥）。

---

## 5. 回滚

| 范围 | 做法 |
|---|---|
| 站点侧 | 逐个文件用改前备份覆盖；**本功能新增的 `xhr/call_log.php`（通话记录）** 直接删除即可停用该子功能（已写入的历史记录消息仍在 `Wo_Messages` 表里，可按 `type_two='call_log'` 清理） |
| 信令服务 | `systemctl disable --now peerjs`，删 `/etc/systemd/system/peerjs.service` 与 `/www/server/peerjs`，`systemctl daemon-reload` |
| 反代 | 删 `extension/<域名>/peerjs-ws.conf` 后 `apachectl -k graceful` |
| 中继 | `systemctl disable --now coturn`（关闭后通话退化为纯直连，对称 NAT 下会连不上） |
| 开关 | 把 `p2p_chat_video` 改回 0，站点即回到 Agora/Twilio 分支（对应配置需另配） |

本机导出时的改前备份目录：`/www/backup/seosq_dev_backups/call_log_msg_20260925_214916/`（通话记录功能）、
`/www/backup/seosq_dev_backups/call_timer_20260925_214209/`、`/www/backup/seosq_dev_backups/call_ui_quality_20260925_204115/`（更早的通话 UI 改动）。

---

## 6. 已知限制与注意事项

1. **只有 Sean 主题**做了本方案的模板改造；备用主题 `Seanq` 未同步（其通话模板仍是未接入 P2P 的旧版）。
   换主题后：通话会回落到 Agora/Twilio 分支逻辑，聊天记录里的通话记录行会退化成普通文本气泡（内容不丢）。
2. **`requests.php` 强制要求 `X-Requested-With: XMLHttpRequest`**，所以通话结束时用的是「先上报、再跳转」
   （最多等 1.5 秒），`navigator.sendBeacon` 走不通。直接关标签页可能来不及上报，
   但对方页面也会上报同一次通话（服务端按房间号去重），所以记录不会丢。
3. **TURN 密钥三处必须一致**（`/etc/turn-rest-secret`、`/etc/coturn/turn-rest-secret`、
   coturn 的 `static-auth-secret`），站点只读它找到的第一个。`turnserver.conf` 默认 `640 root:coturn`，
   www 读不到，所以必须单独放 `/etc/turn-rest-secret`（`640 root:www`）。
4. **Cloudflare 场景**：TURN 必须用源站真实 IP（UDP 不能走 CF 代理）；信令 WSS 走 CF 没问题。
5. **coturn 无日志**（配置里 `no-stdout-log` 且无 `log-file`），需要日志自行加 `log-file=`。
6. 通话记录消息会走 `Wo_RegisterMessage`，因此也继承站点的 AI 机器人钩子：
   若对端是 AI 机器人账号（user_id 738），会触发一次 `ai_handler.php`（站点既有行为，未改动）。
7. HTTP 明文站点也能用（`new Peer` 会按 `location.protocol` 选择 ws/wss），但生产建议强制 HTTPS。

---

## 7. 导出环境（可复现对照）

```
站点        www.seosq.com（WowWonder，主题 Sean，文档根 /www/wwwroot/www.seosq.com）
系统        CentOS 7 / Linux 3.10.0-1160.119.1.el7.x86_64 / glibc 2.17
Web         Apache 2.4.68（直接监听 80/443，前面是 Cloudflare）
PHP         7.4.33（disable_functions 为空）
MySQL       5.7.44-log（GET_LOCK 可用）
Node        v16.20.2
coturn      4.6.2-2.el7
信令        127.0.0.1:9000（systemd: peerjs，User=www）
中继        UDP 3478 + 50000-50100（external-ip 43.161.218.69 / 内网 10.5.0.4）
```

文件级清单与校验值见 `MANIFEST.md` 与 `MANIFEST.md5`。
本包**不含任何密钥明文**：coturn 的 `static-auth-secret` 已替换为占位符，
`/etc/turn-rest-secret` 只以说明形式给出（见 `server/coturn/README-coturn.md`）。
