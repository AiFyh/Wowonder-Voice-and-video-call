-- ============================================================================
-- 语音/视频通话功能必需的全站开关（导出自 www.seosq.com，2026-09-25）
--
-- 表 Wo_Config(id, name, value)，name 上没有唯一索引，所以用
-- 「先 UPDATE，不存在才 INSERT」的写法保证幂等（重复执行结果一致）。
--
-- 含义：
--   p2p_chat_video   = 1  用自建 WebRTC P2P 通道（PeerJS 信令 + 自建 coturn），也就是本包这套
--   agora_chat_video = 0  关掉 Agora 通道（否则 sources/video.php 会走 Agora 分支）
--   twilio_video_chat= 0  关掉 Twilio 通道
--   video_chat       = 1  允许视频通话（sources/video.php 的入口开关）
--   audio_chat       = 1  允许语音通话（xhr/messages.php 里判断「对方是否可被呼叫」）
--
-- ⚠ 站点启用了 Memcached 配置缓存（Wo_GetConfig 缓存 key = md5(site_url)+'config'，TTL 300 秒）：
--   直接跑本 SQL 后最多 5 分钟才会生效。想立刻生效：清掉该 key / 重启 memcached，
--   或改用后台「设置」界面修改（会即时清缓存）。本文件用于批量部署或换机。
-- ============================================================================

UPDATE Wo_Config SET value='1' WHERE name='p2p_chat_video';
INSERT INTO Wo_Config (name, value) SELECT 'p2p_chat_video','1' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM Wo_Config WHERE name='p2p_chat_video');

UPDATE Wo_Config SET value='0' WHERE name='agora_chat_video';
INSERT INTO Wo_Config (name, value) SELECT 'agora_chat_video','0' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM Wo_Config WHERE name='agora_chat_video');

UPDATE Wo_Config SET value='0' WHERE name='twilio_video_chat';
INSERT INTO Wo_Config (name, value) SELECT 'twilio_video_chat','0' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM Wo_Config WHERE name='twilio_video_chat');

UPDATE Wo_Config SET value='1' WHERE name='video_chat';
INSERT INTO Wo_Config (name, value) SELECT 'video_chat','1' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM Wo_Config WHERE name='video_chat');

UPDATE Wo_Config SET value='1' WHERE name='audio_chat';
INSERT INTO Wo_Config (name, value) SELECT 'audio_chat','1' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM Wo_Config WHERE name='audio_chat');

-- 校验（期望：p2p_chat_video=1、video_chat=1、audio_chat=1、agora_chat_video=0、twilio_video_chat=0）
SELECT name, value FROM Wo_Config
WHERE name IN ('p2p_chat_video','agora_chat_video','twilio_video_chat','video_chat','audio_chat');

-- 说明：通话过程中用到的两张临时表由站点自身代码维护（xhr/create_new_video_call.php 等），
-- 建表语句随 WowWonder 主程序升级带来，本包不含建表 SQL：
--   Wo_VideoCalles（视频通话房间：from_id/to_id/room_name/access_token/access_token_2）
--   Wo_AudioCalles（语音通话房间：同上 + active/declined）
-- 换机后可用下面两句确认这两张表存在：
--   SELECT COUNT(*) FROM Wo_VideoCalles;
--   SELECT COUNT(*) FROM Wo_AudioCalles;
