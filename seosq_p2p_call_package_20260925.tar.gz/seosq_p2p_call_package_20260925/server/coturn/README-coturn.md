# coturn（STUN/TURN 中继）说明

本机实测环境：`coturn-4.6.2-2.el7.x86_64`（CentOS 7 / EPEL），服务名 `coturn`，
配置文件 `/etc/coturn/turnserver.conf`（权限 `640 root:coturn`，**www 用户读不到**）。

## 1. 安装

```bash
yum install -y epel-release          # CentOS 7 需要 EPEL 才有 coturn
yum install -y coturn
```

## 2. 配置

用本目录的 `turnserver.conf.template` 作为起点：

```bash
cp turnserver.conf.template /etc/coturn/turnserver.conf
SECRET=$(openssl rand -hex 32)          # 生成 TURN 共享密钥（不要用示例里的占位符）
sed -i "s|<PLEASE-GENERATE-YOUR-OWN-SECRET>|${SECRET}|" /etc/coturn/turnserver.conf
# 再按目标机实际情况改这三行（内网 IP / 公网 IP）：
#   listening-ip / relay-ip = 内网 IP
#   external-ip = 公网IP/内网IP
#   realm = 站点域名
chown root:coturn /etc/coturn/turnserver.conf && chmod 640 /etc/coturn/turnserver.conf
```

### 密钥必须与站点侧一致（最容易踩的坑）

站点代码 `xhr/p2p_turn.php` 里的 `wo_turn_secret()` 按顺序找密钥：

1. `/etc/turn-rest-secret`（推荐；本站就是这种，权限 `640 root:www`）
2. `/etc/coturn/turn-rest-secret`
3. `/etc/coturn/turnserver.conf` 里的 `static-auth-secret`（需要 www 能读该文件才行）

**站点读到的那个值必须与 coturn 实际使用的 `static-auth-secret` 完全相同**，
否则 coturn 会拒绝浏览器拿到的临时账号，表现为「只有直连能通、中继不可用」（弱网/对称 NAT 下就打不通）。

本站做法（推荐照抄，因为 turnserver.conf 是 640 root:coturn，www 读不到）：

```bash
printf '%s' "$SECRET" > /etc/turn-rest-secret     # 内容与 static-auth-secret 一致，末尾不要换行
chown root:www /etc/turn-rest-secret && chmod 640 /etc/turn-rest-secret
su -s /bin/sh www -c 'test -r /etc/turn-rest-secret && echo OK'   # 必须输出 OK
```

### 公网 IP（自动识别，换机不用改代码）

`xhr/p2p_turn.php` 的 `wo_turn_public_ip()`：优先读 `/etc/turn-public-ip`（可选，多公网 IP/特殊网络时用），
否则用 STUN Binding + 回显服务自动探测，结果缓存 6 小时到 `/tmp/seosq-turn-public-ip`。
本站没有 `/etc/turn-public-ip`，靠自动探测（当前探测到 43.161.218.69）。若探测失败，可显式写死：

```bash
echo '1.2.3.4' > /etc/turn-public-ip
```

## 3. 启动与放行

```bash
systemctl enable --now coturn
systemctl status coturn --no-pager | head -5
ss -lunp | grep 3478                 # 期望看到 turnserver 监听 3478/udp
```

需要在**云安全组 / 服务器防火墙**放行（UDP）：

| 端口 | 用途 |
|---|---|
| 3478/udp | STUN + TURN 信令 |
| 50000-50100/udp | TURN 中继端口（来自 `min-port` / `max-port`） |

⚠ 站点走 Cloudflare 代理时，UDP 到不了源站：站点侧只能用**源站真实公网 IP** 走 TURN
（这正是 `wo_turn_public_ip()` 自动探测 IP 的原因）。若要把 TURN 域名也接入，必须把该子域改成 DNS 直连（灰云）。

## 4. 日志

本站 `turnserver.conf` 里是 `no-stdout-log` 且没有配 `log-file`，所以 **coturn 没有日志**。
想观察中继用量，可临时用：

```bash
ss -unap | grep -cE ':(500[0-9][0-9]|50100)'   # 当前活跃中继端口数
```

需要正式日志时，在配置里加 `log-file=/var/log/turnserver.log`（`simple-log` 可选）后重启 coturn。
